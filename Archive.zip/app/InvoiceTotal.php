<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class InvoiceTotal extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'invoice_totals';


}