<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GroupChatMessageStatus extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'group_chat_message_status';	
	
}