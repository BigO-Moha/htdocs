<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PurchaseReturnItemTax extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'purchase_return_item_taxes';

}