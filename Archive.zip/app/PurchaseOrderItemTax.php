<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PurchaseOrderItemTax extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'purchase_order_item_taxes';

}